import React from 'react'


const CLASS_NAME = ({}) => (
  <div>

  </div>
)

export default CLASS_NAME
