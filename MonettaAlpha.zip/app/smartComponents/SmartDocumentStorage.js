import React from 'react'

export default class SmartTeamStorage extends React.Component {
  constructor(props) {
    super(props)
    this.state = {}
  }

  render () {
    //---------------------------CONDITIONS-------------------------------------

    //----------------------------RETURN----------------------------------------
    return(
      <div>
        <h1> SmartTeamStorage </h1>
      </div>
    )
  }
}
