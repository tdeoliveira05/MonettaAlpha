import React from 'react'


const DumbPrepareMeeting = ({}) => (
  <div>
    <h1> DumbReviewMinutes </h1>
  </div>
)

export default DumbPrepareMeeting
