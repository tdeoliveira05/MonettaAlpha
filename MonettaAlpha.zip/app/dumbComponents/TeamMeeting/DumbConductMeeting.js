import React from 'react'


const DumbPrepareMeeting = ({}) => (
  <div>
    <h1> DumbConductMeeting </h1>
  </div>
)

export default DumbPrepareMeeting
