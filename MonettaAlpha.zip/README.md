# MonetaMVP
CHECK BELOW

Pre-Deployment Checklist :

App.js - this.state({
  page: 'Home', 
  tabValue: 'a'
})

Meeting.js - this.state({
  pane: 'Info'
})

Heading.js - this.state({
  logoClick: 'Notif'
})
