# MonettaAlpha
Monetta's first prototype of the virtual assistant for limited testing during Alpha phase.
